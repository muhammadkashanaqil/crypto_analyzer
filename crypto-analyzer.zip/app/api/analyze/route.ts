import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    // const formData = await request.formData()
    // const file = formData.get("file") as File
    // const fileUrl = formData.get("fileUrl") as string
    const {image_url, uploadId} = await request.json();

    // if (!file && !fileUrl) {
    //   return NextResponse.json({ error: "No file or URL provided" }, { status: 400 })
    // }
    const n8nWebhookUrl = 'https://frostoscar440.app.n8n.cloud/webhook/webhook'

    const response = await fetch(n8nWebhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image_url, uploadId }),
    });

    if (!response.ok) {
      console.error('n8n webhook error:', await response.text());
      return NextResponse.json({ error: 'Failed to process the file' }, { status: 500 });
    }

    const n8nResult = await response.json();
    console.log('n8n webhook response:', n8nResult);
    // Simulate AI analysis processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Mock analysis results
    // const analysisResult = {
    //   summary:
    //     "This document discusses a peer-to-peer electronic cash system that enables direct online payments between parties without requiring financial institutions. The system uses cryptographic proof instead of trust, solving the double-spending problem through a peer-to-peer network that timestamps transactions using proof-of-work consensus.",
    //   keywords: [
    //     "peer-to-peer",
    //     "electronic cash",
    //     "cryptographic proof",
    //     "blockchain",
    //     "consensus",
    //     "double-spending",
    //   ],
    //   mainArgument:
    //     "A decentralized electronic payment system can eliminate the need for trusted third parties by using cryptographic proof and distributed consensus, creating a more robust and censorship-resistant financial infrastructure.",
    //   confidence: 0.92,
    //   fileType: file ? file.type : "url",
    //   fileName: file ? file.name : "URL Content",
    //   analyzedAt: new Date().toISOString(),
    // }

    return NextResponse.json({
      success: true,
      analysis: n8nResult,
    })
  } catch (error) {
    console.error("Analysis error:", error)
    return NextResponse.json({ error: "Analysis failed" }, { status: 500 })
  }
}
