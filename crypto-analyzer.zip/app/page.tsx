"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Upload, FileText, Search, CheckCircle, MessageCircle } from "lucide-react"
import { WalletConnection } from "@/components/wallet-connection"
import { FileUpload } from "@/components/file-upload"
import { useToast } from "@/hooks/use-toast"

export default function HomePage() {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [fileUrl, setFileUrl] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const { toast } = useToast()

  const handleFileUpload = (file: File) => {
    setUploadedFile(file)
    setFileUrl("")
  }

  const handleUrlUpload = () => {
    if (fileUrl.trim()) {
      setUploadedFile(null)
      // Handle URL upload logic here
    }
  }

  const handleAnalyze = async () => {
    if (!uploadedFile && !fileUrl.trim()) return

    setIsAnalyzing(true)

    try {
      const formData = new FormData()
      if (uploadedFile) {
        formData.append("file", uploadedFile)
      } else {
        formData.append("fileUrl", fileUrl)
      }

      const response = await fetch("/api/analyze", {
        method: "POST",
        body: JSON.stringify({ image_url: fileUrl, uploadId: uploadedFile ? uploadedFile.name : fileUrl }),
      })

      const result = await response.json()

      if (result.success) {
        // Store analysis result in sessionStorage for the analysis page
        sessionStorage.setItem("analysisResult", JSON.stringify(result.analysis))
        sessionStorage.setItem("uploadedFile", uploadedFile ? uploadedFile.name : fileUrl)

        // Navigate to analysis results
        window.location.href = "/analysis"
      } else {
        toast({
          title: "Analysis Failed",
          description: result.error || "Something went wrong during analysis",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Analysis error:", error)
      toast({
        title: "Analysis Failed",
        description: "Unable to analyze the file. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="min-h-screen bg-background calcback" style={{ backgroundColor: '#0c121dff'}}>
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <FileText className="w-5 h-5 text-primary-foreground" />
          </div>
          <span className="text-3xl font-bold text-foreground" style={{ fontFamily: 'Chunko Bold Demo' }}>CryptoAnalyzer</span>
        </div>
        <WalletConnection />
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-6xl calcback">
        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* Left Column - Content */}
          <div className="space-y-8">
            <div className="space-y-4" style={{ fontFamily: 'Gilroy' }}>
              <h1 className="text-4xl font-bold text-balance">
                <span className="text-primary" style={{ fontFamily: 'Chunko Bold Demo' }}>Analytics</span>
                <br />
                <span className="text-foreground" style={{ fontFamily: 'Chunko Bold Demo' }}>Tool</span>
              </h1>
              <p className="text-lg text-muted-foreground text-pretty leading-relaxed">
                Understand complex content in seconds. Upload a PDF or screenshot any crypto content - whitepapers,
                audits, threads, or on-chain data and get instant insights.
              </p>
            </div>

            {/* Features List */}
            <div className="space-y-4" style={{ fontFamily: 'Gilroy' }}>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-primary" />
                <span className="text-foreground">Summary in plain English (or degen-speak)</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-primary" />
                <span className="text-foreground">Keywords & definitions (DeFi, restaking, MEV, etc.)</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-primary" />
                <span className="text-foreground">Main argument or narrative (What are they actually saying?)</span>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-primary" />
                <span className="text-foreground">AI chat assistant to explore further</span>
              </div>
            </div>
          </div>

          {/* Right Column - Upload Area */}
          <div className="space-y-6" >
            <Card className="bg-card border-border" style={{ backgroundColor: '#151a24ff'}}>
              <CardContent className="p-6">
                <div className="space-y-4" style={{ fontFamily: 'Gilroy' }}>
                  <div className="flex items-center gap-2 mb-4">
                    <Upload className="w-5 h-5 text-primary" />
                    <h3 className="text-lg font-semibold text-card-foreground">Upload Files</h3>
                  </div>

                  <FileUpload onFileUpload={handleFileUpload} />

                  <div className="text-center text-muted-foreground">or</div>

                  <div className="space-y-2">
                    <Input
                      placeholder="Paste file URL here"
                      value={fileUrl}
                      onChange={(e) => setFileUrl(e.target.value)}
                      className="bg-input border-border text-foreground"
                    />
                    <Button
                      variant="outline"
                      onClick={handleUrlUpload}
                      className="w-full bg-transparent"
                      disabled={!fileUrl.trim()}
                      style={{ fontFamily: 'Chunko Bold Demo' }}
                    >
                      Upload
                    </Button>
                  </div>

                  <Button
                    onClick={handleAnalyze}
                    disabled={(!uploadedFile && !fileUrl.trim()) || isAnalyzing}
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                    style={{ fontFamily: 'Chunko Bold Demo' }}
                  >
                    {isAnalyzing ? "Analyzing..." : "Analyze"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Steps Section */}
        <div className="mt-16 grid md:grid-cols-4 gap-8" style={{ fontFamily: 'Gilroy' }} >
          <div className="text-center space-y-4" >
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
              <Upload className="w-6 h-6 text-primary" style={{ color: "white" }}/>
            </div>
            <h3 className="font-semibold text-primary" style={{ color: "white" }}>Step 1:</h3>
            <p className="text-sm text-muted-foreground" style={{ color: "white" }}>Upload your crypto document, whitepaper, or screenshot</p>
          </div>

          <div className="text-center space-y-4">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
              <Search className="w-6 h-6 text-primary" style={{ color: "white" }}/>
            </div>
            <h3 className="font-semibold text-primary" style={{ color: "white" }}>Step 2:</h3>
            <p className="text-sm text-muted-foreground" style={{ color: "white" }}>AI analyzes the content and extracts key insights</p>
          </div>

          <div className="text-center space-y-4">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
              <CheckCircle className="w-6 h-6 text-primary" style={{ color: "white" }}/>
            </div>
            <h3 className="font-semibold text-primary" style={{ color: "white" }}>Step 3:</h3>
            <p className="text-sm text-muted-foreground" style={{ color: "white" }}>Get plain English summaries and key definitions</p>
          </div>

          <div className="text-center space-y-4">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
              <MessageCircle className="w-6 h-6 text-primary" style={{ color: "white" }}/>
            </div>
            <h3 className="font-semibold text-primary" style={{ color: "white" }}>Step 4:</h3>
            <p className="text-sm text-muted-foreground" style={{ color: "white" }}>Chat with AI to explore deeper insights and ask questions</p>
          </div>
        </div>
      </main>
    </div>
  )
}
