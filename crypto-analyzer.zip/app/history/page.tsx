"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, FileText, Trash2, Calendar, Eye } from "lucide-react"
import { WalletConnection } from "@/components/wallet-connection"
import { Badge } from "@/components/ui/badge"

interface AnalysisHistoryItem {
  id: string
  fileName: string
  fileType: "pdf" | "image"
  analyzedAt: string
  summary: string
  keywords: string[]
}

export default function HistoryPage() {
  const [historyItems, setHistoryItems] = useState<AnalysisHistoryItem[]>([
    {
      id: "1",
      fileName: "Bitcoin Whitepaper.pdf",
      fileType: "pdf",
      analyzedAt: "2024-01-15T10:30:00Z",
      summary: "Analysis of Bitcoin's peer-to-peer electronic cash system proposal...",
      keywords: ["peer-to-peer", "electronic cash", "cryptographic proof"],
    },
    {
      id: "2",
      fileName: "Ethereum Yellow Paper.pdf",
      fileType: "pdf",
      analyzedAt: "2024-01-14T15:45:00Z",
      summary: "Technical specification of the Ethereum Virtual Machine and protocol...",
      keywords: ["smart contracts", "EVM", "gas", "consensus"],
    },
    {
      id: "3",
      fileName: "DeFi Protocol Screenshot.png",
      fileType: "image",
      analyzedAt: "2024-01-13T09:15:00Z",
      summary: "Analysis of a DeFi protocol interface showing yield farming opportunities...",
      keywords: ["DeFi", "yield farming", "liquidity pools"],
    },
    {
      id: "4",
      fileName: "Coin and head.png",
      fileType: "image",
      analyzedAt: "2024-01-12T14:20:00Z",
      summary: "Analysis of cryptocurrency token design and branding elements...",
      keywords: ["token design", "branding", "cryptocurrency"],
    },
  ])

  const handleBack = () => {
    window.location.href = "/"
  }

  const handleDelete = (id: string) => {
    setHistoryItems((prev) => prev.filter((item) => item.id !== id))
  }

  const handleView = (id: string) => {
    // In a real implementation, this would navigate to the specific analysis
    window.location.href = "/analysis"
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
  <div className="min-h-screen"style={{ backgroundColor: '#151a24ff'}}>
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={handleBack} className="gap-2" style={{fontFamily: 'Gilroy'}}>
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <h1 className="text-xl font-semibold text-foreground" style={{fontFamily: 'Chunko Bold Demo'}}>Analysis History</h1>
        </div>
        <WalletConnection />
      </header>
      {/* <div className="border-b border-border" />
          <Button variant="ghost" size="sm" onClick={handleBack} className="gap-2" style={{fontFamily: 'Gilroy'}}>
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button> */}
      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground" style={{fontFamily: 'Chunko Bold Demo'}}>Your Analysis History</h2>
              <p className="text-muted-foreground mt-1" style={{fontFamily: 'Gilroy'}}>View and manage your previous crypto document analyses</p>
            </div>
            <Badge variant="secondary" className="bg-primary/10 text-primary" style = {{fontFamily: 'Gilroy'}}>
              {historyItems.length} analyses
            </Badge>
          </div>

          {historyItems.length === 0 ? (
            <Card className="bg-card border-border">
              <CardContent className="p-12 text-center">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-card-foreground mb-2">No analysis history</h3>
                <p className="text-muted-foreground">
                  Your analyzed documents will appear here once you start using the tool.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {historyItems.map((item) => (
                <Card key={item.id} className="bg-card border-border hover:border-primary/50 transition-colors">
                  <CardHeader className="pb-3" style={{fontFamily: 'Chunko Demo'}}>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                          <FileText className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-card-foreground text-base">{item.fileName}</CardTitle>
                          <div className="flex items-center gap-2 mt-1">
                            <Calendar className="w-3 h-3 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">{formatDate(item.analyzedAt)}</span>
                            <Badge variant="outline" className="text-xs bg-transparent border-muted-foreground/20">
                              {item.fileType.toUpperCase()}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm" onClick={() => handleView(item.id)} className="gap-2" style={{fontFamily: 'Gilroy'}}>
                          <Eye className="w-4 h-4" />
                          View
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(item.id)}
                          className="gap-2 text-destructive hover:text-destructive" style={{fontFamily: 'Gilroy'}}
                        >
                          <Trash2 className="w-4 h-4" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent style={{fontFamily: 'Gilroy'}}>
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{item.summary}</p>
                    <div className="flex flex-wrap gap-2">
                      {item.keywords.map((keyword, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="text-xs bg-primary/10 text-primary hover:bg-primary/20"
                        >
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
