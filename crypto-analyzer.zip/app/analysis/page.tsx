"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Share, Download } from "lucide-react"
import { WalletConnection } from "@/components/wallet-connection"
import { FileViewer } from "@/components/file-viewer"
import { AnalysisResults } from "@/components/analysis-results"
import { ChatInterface } from "@/components/chat-interface"

type ChatMessage = {
  role: "assistant" | "user";
  content: string;
};

export default function AnalysisPage() {
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: "Ask me anything about your upload's analysis",
    },
  ])
  const [inputMessage, setInputMessage] = useState("")

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return

    setChatMessages((prev) => [
      ...prev,
      { role: "user" as const, content: inputMessage },
      {
        role: "assistant" as const,
        content: "This is a simulated response. In a real implementation, this would connect to your AI analysis API.",
      },
    ])
    setInputMessage("")
  }

  const handleBack = () => {
    window.location.href = "/"
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={handleBack} className="gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center">
              <span className="text-xs font-bold text-primary-foreground">C</span>
            </div>
            <span className="font-medium text-2xl text-foreground"  style={{fontFamily: 'Chunko Bold Demo'}}>Coin and head.png</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* <Button variant="ghost" size="sm" className="gap-2">
            <Share className="w-4 h-4" />
            Share
          </Button>
          <Button variant="ghost" size="sm" className="gap-2">
            <Download className="w-4 h-4" />
            Export
          </Button> */}
          <WalletConnection />
        </div>
      </header>

      {/* Main Content - Split View */}
      <div className="flex h-[calc(100vh-73px)]">
        {/* Left Panel - File Viewer */}
        <div className="w-1/2 border-r border-border">
          <div className="p-6 h-full">
            <div className="mb-4">
              <h2 className="text-xl font-semibold text-primary mb-2"  style={{fontFamily: 'Chunko Bold Demo'}}>Your upload</h2>
            </div>
            <FileViewer />
          </div>
        </div>

        {/* Right Panel - Analysis Results */}
        <div className="w-1/2 flex flex-col">
          <div className="flex-1 overflow-y-auto">
            <div className="p-6">
              <h2 className="text-lg font-semibold text-primary mb-6">Analysis</h2>
              <AnalysisResults />
            </div>
          </div>

          {/* Chat Interface */}
          <div className="border-t border-border">
            <ChatInterface
              messages={chatMessages}
              inputMessage={inputMessage}
              setInputMessage={setInputMessage}
              onSendMessage={handleSendMessage}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
