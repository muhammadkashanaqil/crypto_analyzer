"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Wallet, ChevronDown, History, LogOut } from "lucide-react"
import { useWalletKit, ConnectButton } from "@mysten/wallet-kit"

export function WalletConnection() {
  const { currentAccount, isConnected, disconnect } = useWalletKit()
  const [walletAddress, setWalletAddress] = useState("")

  useEffect(() => {
    if (currentAccount?.address) {
      setWalletAddress(currentAccount.address)
    } else {
      setWalletAddress("")
    }
  }, [currentAccount])

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`
  }

  const viewHistory = () => {
    window.location.href = "/history"
  }

  const handleDisconnect = () => {
    disconnect()
  }

  if (!isConnected) {
    //@ts-ignore
    return <ConnectButton className = "bg-gray-200" style = {{ fontFamily: 'Chunko Bold Demo' }} />;
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="gap-2 hover: bg-gray-200 dark:hover:bg-gray-700" style = {{ fontFamily: 'Gilroy' }}>
          <Wallet className="w-4 h-4 mr-2" />
          {walletAddress ? formatAddress(walletAddress) : "Connected"}
          <ChevronDown className="w-4 h-4 ml-2" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56" style = {{ fontFamily: 'Gilroy' }}>
        <DropdownMenuItem onClick={viewHistory} className="gap-2">
          <History className="w-4 h-4" />
          View Wallet Analyze History
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleDisconnect} className="gap-2" style = {{ fontFamily: 'Gilroy' }}>
          <LogOut className="w-4 h-4" />
          Disconnect
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}