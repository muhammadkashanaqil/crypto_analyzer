"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { MessageCircle, Send } from "lucide-react"

interface Message {
  role: "user" | "assistant"
  content: string
}

interface ChatInterfaceProps {
  messages: Message[]
  inputMessage: string
  setInputMessage: (message: string) => void
  onSendMessage: () => void
}

export function ChatInterface({ messages, inputMessage, setInputMessage, onSendMessage }: ChatInterfaceProps) {
  const [isLoading, setIsLoading] = useState(false)

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return

    setIsLoading(true)
    const userMessage = inputMessage
    setInputMessage("")

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userMessage,
          context: "crypto analysis", // You can pass analysis context here
        }),
      })

      const result = await response.json()

      if (result.success) {
        // This would typically be handled by the parent component
        onSendMessage()
      }
    } catch (error) {
      console.error("Chat error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center gap-2 text-primary">
        <MessageCircle className="w-5 h-5" />
        <span className="font-semibold" style={{fontFamily: 'Chunko Demo'}}>Ask me anything about your upload's analysis</span>
      </div>

      {/* Chat Messages */}
      <div className="space-y-3 max-h-48 overflow-y-auto">
        {messages.map((message, index) => (
          <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`} style={{fontFamily: 'Gilroy'}}>
            <Card
              className={`max-w-[80%] ${
                message.role === "user"
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground border-border"
              }`}
            >
              <CardContent className="p-3">
                <p className="text-sm">{message.content}</p>
              </CardContent>
            </Card>
          </div>
        ))}
      </div>

      {/* Chat Input */}
      <div className="flex gap-2">
        <Input
          placeholder="Ask about the document..."
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          className="flex-1 bg-input border-border text-foreground"
          style={{fontFamily: 'Gilroy'}}
          disabled={isLoading}
        />
        <Button onClick={handleSendMessage} disabled={!inputMessage.trim() || isLoading} size="sm" className="px-3">
          <Send className="w-4 h-4" />
        </Button>
      </div>

      {/* Conversation Starter */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 text-muted-foreground">
          <MessageCircle className="w-4 h-4" />
          <span className="text-sm" style={{fontFamily: 'Gilroy'}}>Start a conversation about the document</span>
        </div>
      </div>
    </div>
  )
}
