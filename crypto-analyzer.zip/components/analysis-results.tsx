"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FileText, Target } from "lucide-react"

export function AnalysisResults() {
  const keywords = ["peer-to-peer", "electronic cash", "cryptographic proof", "decentralized", "blockchain"]

  return (
    <div className="space-y-6">
      {/* Summary Section */}
      <Card className="bg-card border-border" >
        <CardHeader className="pb-3" style={{fontFamily: 'Chunko Demo'}}>
          <CardTitle className="flex items-center gap-2 text-primary" style={{fontFamily: 'Chunko Demo'}}>
            <FileText className="w-5 h-5" />
            Summary
          </CardTitle>
        </CardHeader>
        <CardContent style={{fontFamily: 'Gilroy'}}>
          <p className="text-card-foreground leading-relaxed">
            This paper proposes a peer-to-peer electronic cash system called Bitcoin that allows online payments to be
            sent directly between parties without relying on trusted third parties like financial institutions. It
            solves the double-spending problem using a peer-to-peer network that timestamps transactions by hashing them
            into an ongoing chain of proof-of-work. The longest chain serves as proof of the transaction history,
            secured by the majority of CPU power on the network. The system is designed to be robust and decentralized,
            allowing nodes to join and leave at will, and incentivizes participation through new coin creation and
            transaction fees.
          </p>
        </CardContent>
      </Card>

      {/* Keywords Section */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-primary" style={{fontFamily: 'Chunko Demo'}}>Keywords & Definitions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2" style={{fontFamily: 'Gilroy'}}>
            {keywords.map((keyword, index) => (
              <Badge key={index} variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                {keyword}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Main Argument Section */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-primary" style={{fontFamily: 'Chunko Demo'}}>
            <Target className="w-5 h-5" />
            Main argument
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-card-foreground leading-relaxed" style={{fontFamily: 'Gilroy'}}>
            A purely peer-to-peer electronic cash system based on cryptographic proof, rather than trust, is possible
            through a decentralized network that can create a secure and tamper-proof transaction ledger without
            requiring trusted intermediaries. The key innovation is using proof-of-work to establish consensus and
            prevent double-spending in a distributed system.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
