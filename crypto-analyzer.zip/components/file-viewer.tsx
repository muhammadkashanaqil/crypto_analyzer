"use client"

import { Card } from "@/components/ui/card"

export function FileViewer() {
  // In a real implementation, this would display the actual uploaded file
  // For now, showing the example image from the mockup
  return (
    <Card className="h-full bg-card border-border border-2 border-dashed">
      <div className="h-full flex items-center justify-center p-8">
        <div className="text-center space-y-4">
          {/* Example crypto coin image */}
          <div className="w-64 h-64 mx-auto bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center relative overflow-hidden">
            <div className="w-48 h-48 bg-blue-400 rounded-full flex items-center justify-center relative">
              {/* Coin character face */}
              <div className="text-white text-6xl font-bold">😈</div>
              {/* Coin details/texture */}
              <div className="absolute inset-0 border-8 border-blue-300 rounded-full opacity-50"></div>
              <div className="absolute top-4 left-4 w-8 h-8 bg-white rounded-full opacity-20"></div>
              <div className="absolute top-6 right-6 w-4 h-4 bg-white rounded-full opacity-30"></div>
              <div className="absolute bottom-8 left-8 w-6 h-6 bg-white rounded-full opacity-25"></div>
            </div>
            {/* Coin edge pattern */}
            <div className="absolute inset-0 border-4 border-blue-800 rounded-full"></div>
          </div>
          <p className="text-sm text-muted-foreground">Uploaded file preview</p>
        </div>
      </div>
    </Card>
  )
}
